from setuptools import setup, find_packages

setup(
    name='src', 
    version='0.0.1', 
    description='its a chennai housing price prediction package',
    author="Manirathinam",
    packages=find_packages(),
    )